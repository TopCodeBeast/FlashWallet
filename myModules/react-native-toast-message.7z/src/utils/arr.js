const complement = (arr) => arr.map((i) => -i);

export { complement };
