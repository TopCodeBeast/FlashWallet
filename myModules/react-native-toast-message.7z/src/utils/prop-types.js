import PropTypes from 'prop-types';

const stylePropType = PropTypes.oneOfType([PropTypes.object, PropTypes.number]);

export { stylePropType };
