import { StyleSheet } from 'react-native';

export default StyleSheet.create({
  base: {
    height: 16,
    width: 16
  }
});
